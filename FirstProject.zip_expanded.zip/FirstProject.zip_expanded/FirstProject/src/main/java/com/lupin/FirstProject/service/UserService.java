package com.lupin.FirstProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lupin.FirstProject.domain.User;
import com.lupin.FirstProject.repository.UserRepository;


@Service
public class UserService {

	@Autowired
	private UserRepository repo;
	
	public User login(String username, String password) {
	User user = repo.findByUsernameAndPassword(username, password);
    return user;
}
	
}
